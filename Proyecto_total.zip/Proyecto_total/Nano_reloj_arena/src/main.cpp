#include "Arduino.h"
#include "LedControl.h"
#include "Delay.h"

#include <SPI.h>
#include <Wire.h>
#include <SparkFun_ADXL345.h>
#include <LiquidCrystal_I2C.h>

ADXL345 adxl = ADXL345();

#define  MATRIX_A  1
#define  MATRIX_B  0

// Values are 260/330/400
#define ACC_THRESHOLD_LOW 300
#define ACC_THRESHOLD_HIGH 360

// Matrix
#define PIN_DATAIN 5   // DIN
#define PIN_CLK 4      // CLK
#define PIN_LOAD 6     // CS


// Accelerometer
#define PIN_SDA A4       //SDA
#define PIN_SCL A5       //SCL 

#define PIN_BUZZER 13

// Esto tiene en cuenta cómo se montan las matrices.
#define ROTATION_OFFSET 90

// in milliseconds
#define DEBOUNCE_THRESHOLD 500

//#define DELAY_FRAME 100        //Velocidad de caida de particulas

#define DEBUG_OUTPUT 1

#define MODE_HOURGLASS 0
#define MODE_SETMINUTES 1
#define MODE_SETHOURS 2

// ... tus variables existentes ...
bool esperandoTiempoPara = false; // true para abrir, false para cerrar
// ...
unsigned long startTimeMillis = 0;
unsigned long totalDurationMillis = 0;
bool countdownActive = false;
unsigned long lastSecondUpdate = 0;

// --- NUEVAS VARIABLES PARA EL CONTROL DE LA CAÍDA DE PARTÍCULAS ---
// Este es el delay específico para cada "caída" de una partícula de una matriz a otra
unsigned long particleDropDelayMillis = 1000; // Valor predeterminado: 1 segundo por partícula
NonBlockDelay particleDropTimer; // Nuevo temporizador para la caída de partículas
// --- FIN NUEVAS VARIABLES ---


LiquidCrystal_I2C lcd(0x27, 16, 2);

byte delayHours = 0;
byte delayMinutes = 1;
int mode = MODE_HOURGLASS;
int gravity;
LedControl lc = LedControl(PIN_DATAIN, PIN_CLK, PIN_LOAD, 2);
NonBlockDelay d;
int resetCounter = 0;
bool alarmWentOff = false;

// --- Variables para la comunicación Serial con la ESP32 ---
String receivedMessage = ""; // Almacena el mensaje recibido
bool newMessageFlag = false; // Indica si se ha recibido un mensaje completo

/**
 * Obtener retraso entre caídas de partículas (en segundos)
 */
long getDelayDrop() {
  // Esta función DEBE volver a su estado original.
  // Ahora controla la velocidad de caída "lenta" del modo manual (si se usa).
  // La velocidad de la animación global se gestiona con customLoopDelay.
  return delayMinutes + delayHours * 60; // Tu lógica original
}

#if DEBUG_OUTPUT
void printmatrix() {
  Serial.println(" 0123-4567 ");
  for (int y = 0; y<8; y++) {
    if (y == 4) {
      Serial.println("|----|----|");
    }
    Serial.print(y);
    for (int x = 0; x<8; x++) {
      if (x == 4) {
        Serial.print("|");
      }
      Serial.print(lc.getXY(0,x,y) ? "X" :" ");
    }
    Serial.println("|");
  }
  Serial.println("-----------");
}
#endif



coord getDown(int x, int y) {
  coord xy;
  xy.x = x-1;
  xy.y = y+1;
  return xy;
}
coord getLeft(int x, int y) {
  coord xy;
  xy.x = x-1;
  xy.y = y;
  return xy;
}
coord getRight(int x, int y) {
  coord xy;
  xy.x = x;
  xy.y = y+1;
  return xy;
}


bool canGoLeft(int addr, int x, int y) {
  if (x == 0) return false; // not available
  return !lc.getXY(addr, getLeft(x, y));              // you can go there if this is empty
}
bool canGoRight(int addr, int x, int y) {
  if (y == 7) return false; // not available
  return !lc.getXY(addr, getRight(x, y));             // you can go there if this is empty
}
bool canGoDown(int addr, int x, int y) {
  if (y == 7) return false; // not available
  if (x == 0) return false; // not available
  if (!canGoLeft(addr, x, y)) return false;
  if (!canGoRight(addr, x, y)) return false;
  return !lc.getXY(addr, getDown(x, y));              // you can go there if this is empty
}



void goDown(int addr, int x, int y) {
  lc.setXY(addr, x, y, false);
  lc.setXY(addr, getDown(x,y), true);
}
void goLeft(int addr, int x, int y) {
  lc.setXY(addr, x, y, false);
  lc.setXY(addr, getLeft(x,y), true);
}
void goRight(int addr, int x, int y) {
  lc.setXY(addr, x, y, false);
  lc.setXY(addr, getRight(x,y), true);
}


int countParticles(int addr) {
  int c = 0;
  for (byte y=0; y<8; y++) {
    for (byte x=0; x<8; x++) {
      if (lc.getXY(addr, x, y)) {
        c++;
      }
    }
  }
  return c;
}


bool moveParticle(int addr, int x, int y) {
  if (!lc.getXY(addr,x,y)) {
    return false;
  }

  bool can_GoLeft = canGoLeft(addr, x, y);
  bool can_GoRight = canGoRight(addr, x, y);

  if (!can_GoLeft && !can_GoRight) {
    return false; // we're stuck
  }

  bool can_GoDown = canGoDown(addr, x, y);

  if (can_GoDown) {
    goDown(addr, x, y);
  } else if (can_GoLeft&& !can_GoRight) {
    goLeft(addr, x, y);
  } else if (can_GoRight && !can_GoLeft) {
    goRight(addr, x, y);
  } else if (random(2) == 1) {                  // Podemos ir a izquierda y derecha, pero no abajo
    goLeft(addr, x, y);
  } else {
    goRight(addr, x, y);
  }
  return true;
}


void fill(int addr, int maxcount) {
  int n = 8;
  byte x,y;
  int count = 0;
  for (byte slice = 0; slice < 2*n-1; ++slice) {
    byte z = slice<n ? 0 : slice-n + 1;
    for (byte j = z; j <= slice-z; ++j) {
      y = 7-j;
      x = (slice-j);
      lc.setXY(addr, x, y, (++count <= maxcount));
    }
  }
}




// Detectar la orientación usando el acelerómetro

int getGravity() {

  int x, y, z;

  adxl.readAccel(&x, &y, &z); 

  if (x >= 20 & z <= 5  )  { return 90;   }                 //Arena hacia la derecha 
  if (x >= -10 & z > 0) { return 180; }                     //Funciona como reloj de arena arriba - abajo
  if (x >= -10 & z <= 25  )  { return 0;   }                //Funciona como reloj de arena abajo - arriba 
  if (x <= -20 & z >= -5) { return 270; }                   //Arena hacia la izquierda          
    
}


int getTopMatrix() {
  return (getGravity() == 90) ? MATRIX_A : MATRIX_B;
}
int getBottomMatrix() {
  return (getGravity() != 90) ? MATRIX_A : MATRIX_B;
}


void resetTime() {
  for (byte i=0; i<2; i++) {
    lc.clearDisplay(i);
  }
  fill(getTopMatrix(), 60); // Rellena la matriz superior con 60 partículas
  
  // Reinicia el temporizador de caída de partículas con el delay actual
  particleDropTimer.Delay(particleDropDelayMillis);
  
  // Opcional: Reinicia el temporizador 'd' para la velocidad de movimiento interno de la matriz
  // Asegúrate de que 'd' tenga un valor por defecto si lo usas para updateMatrix()
  d.Delay(100); // Puedes poner aquí tu DELAY_FRAME original si 'd' controla la velocidad de updateMatrix()
}



/**
 * Atraviese la matriz y compruebe si es necesario mover las partículas
 */
bool updateMatrix() {
  int n = 8;
  bool somethingMoved = false;
  byte x,y;
  bool direction;
  for (byte slice = 0; slice < 2*n-1; ++slice) {
    direction = (random(2) == 1); // randomize if we scan from left to right or from right to left, so the grain doesn't always fall the same direction
    byte z = slice<n ? 0 : slice-n + 1;
    for (byte j = z; j <= slice-z; ++j) {
      y = direction ? (7-j) : (7-(slice-j));
      x = direction ? (slice-j) : j;
      // for (byte d=0; d<2; d++) { lc.invertXY(0, x, y); delay(50); }
      if (moveParticle(MATRIX_B, x, y)) {
        somethingMoved = true;
      };
      if (moveParticle(MATRIX_A, x, y)) {
        somethingMoved = true;
      }
    }
  }
  return somethingMoved;
}



/**
 * Deja que una partícula pase de una matriz a otra
 */
boolean dropParticle() {
  // Ahora usamos el nuevo temporizador particleDropTimer y particleDropDelayMillis
  if (particleDropTimer.Timeout()) {
    particleDropTimer.Delay(particleDropDelayMillis); // Establece el próximo drop con el delay calculado

    if (gravity == 0 || gravity == 180) { // Solo si la gravedad es vertical
      if ((lc.getRawXY(MATRIX_A, 0, 0) && !lc.getRawXY(MATRIX_B, 7, 7)) ||
          (!lc.getRawXY(MATRIX_A, 0, 0) && lc.getRawXY(MATRIX_B, 7, 7))
      ) {
        lc.invertRawXY(MATRIX_A, 0, 0);
        lc.invertRawXY(MATRIX_B, 7, 7);
        tone(PIN_BUZZER, 440, 10);
        return true;
      }
    }
  }
  return false;
}



void alarm() {
  for (int i=0; i<5; i++) {
    tone(PIN_BUZZER, 440, 200);
    delay(1000);
  }
}

void resetCheck() {
  int z = analogRead(A3);
  if (z > ACC_THRESHOLD_HIGH || z < ACC_THRESHOLD_LOW) {
    resetCounter++;
    Serial.println(resetCounter);
  } else {
    resetCounter = 0;
  }
  if (resetCounter > 20) {
    Serial.println("RESET!");
    resetTime();
    resetCounter = 0;
  }
}

void displayLetter(char letter, int matrix) {
  // Serial.print("Letter: ");
  // Serial.println(letter);
  lc.clearDisplay(matrix);
  lc.setXY(matrix, 1,4, true);
  lc.setXY(matrix, 2,3, true);
  lc.setXY(matrix, 3,2, true);
  lc.setXY(matrix, 4,1, true);

  lc.setXY(matrix, 3,6, true);
  lc.setXY(matrix, 4,5, true);
  lc.setXY(matrix, 5,4, true);
  lc.setXY(matrix, 6,3, true);

  if (letter == 'M') {
    lc.setXY(matrix, 4,2, true);
    lc.setXY(matrix, 4,3, true);
    lc.setXY(matrix, 5,3, true);
  }
  if (letter == 'H') {
    lc.setXY(matrix, 3,3, true);
    lc.setXY(matrix, 4,4, true);
  }
}



void renderSetMinutes() {
  fill(getTopMatrix(), delayMinutes);
  displayLetter('M', getBottomMatrix());
}
void renderSetHours() {
  fill(getTopMatrix(), delayHours);
  displayLetter('H', getBottomMatrix());
}




void knobClockwise() {
  Serial.println("Clockwise");
  if (mode == MODE_SETHOURS) {
    delayHours = constrain(delayHours+1, 0, 64);
    renderSetHours();
  } else if(mode == MODE_SETMINUTES) {
    delayMinutes = constrain(delayMinutes+1, 0, 64);
    renderSetMinutes();
  }
  Serial.print("Delay: ");
  Serial.println(getDelayDrop());
}
void knobCounterClockwise() {
  Serial.println("Counterclockwise");
  if (mode == MODE_SETHOURS) {
    delayHours = constrain(delayHours-1, 0, 64);
    renderSetHours();
  } else if (mode == MODE_SETMINUTES) {
    delayMinutes = constrain(delayMinutes-1, 0, 64);
    renderSetMinutes();
  }
  Serial.print("Delay: ");
  Serial.println(getDelayDrop());
}



volatile int lastEncoded = 0;
volatile long encoderValue = 0;
long lastencoderValue = 0;
long lastValue = 0;
void updateEncoder() {
  
/*
  int MSB = digitalRead(PIN_ENC_1); //MSB = most significant bit
  int LSB = digitalRead(PIN_ENC_2); //LSB = least significant bit
*/

  int MSB = 0; //MSB = most significant bit      //Agregado
  int LSB = 0; //LSB = least significant bit     //Agregado
 

  int encoded = (MSB << 1) |LSB; //converting the 2 pin value to single number
  int sum  = (lastEncoded << 2) | encoded; //adding it to the previous encoded value

  if(sum == 0b1101 || sum == 0b0100 || sum == 0b0010 || sum == 0b1011) encoderValue--;
  if(sum == 0b1110 || sum == 0b0111 || sum == 0b0001 || sum == 0b1000) encoderValue++;

  // Serial.print("Value: ");
  // Serial.println(encoderValue);
  if ((encoderValue % 4) == 0) {
    int value = encoderValue / 4;
    if (value > lastValue) knobClockwise();
    if (value < lastValue) knobCounterClockwise();
    lastValue = value;
  }
  lastEncoded = encoded; //store this value for next time
}



/**
 * Button callback (incl. software debouncer)
 * Esto cambia entre los modos (normal, establecer minutos, establecer horas)
 */
volatile unsigned long lastButtonPushMillis;
void buttonPush() {
  
  if((long)(millis() - lastButtonPushMillis) >= DEBOUNCE_THRESHOLD) {
    mode = (mode+1) % 3;
    Serial.print("Modo cambiado a: ");
    Serial.println(mode);
    lastButtonPushMillis = millis();

    if (mode == MODE_SETMINUTES) {
      lc.backup(); // we only need to back when switching from MODE_HOURGLASS->MODE_SETMINUTES
      renderSetMinutes();
    }
    
    if (mode == MODE_SETHOURS) {
      renderSetHours();
    }
    
    if (mode == MODE_HOURGLASS) {
      lc.clearDisplay(0);
      lc.clearDisplay(1);
      lc.restore();
      resetTime();
    }
    
  }
}


void setup() {
  
  Serial.begin(9600);
  lcd.init();       // Inicializa la pantalla
  lcd.backlight();
  lcd.clear();
  //lcd.setCursor(0, 0);      // Coloca el cursor en la fila 0, columna 0
  //lcd.print("RELOJ DE ARENA"); 
  // configurar el codificador rotatorio
/*
  pinMode(PIN_ENC_1, INPUT);
  pinMode(PIN_ENC_2, INPUT);
  pinMode(PIN_ENC_BUTTON, INPUT);
  digitalWrite(PIN_ENC_1, HIGH); //turn pullup resistor on
  digitalWrite(PIN_ENC_2, HIGH); //turn pullup resistor on
  digitalWrite(PIN_ENC_BUTTON, HIGH); //turn pullup resistor on
  attachInterrupt(digitalPinToInterrupt(PIN_ENC_1), updateEncoder, CHANGE);
  attachInterrupt(digitalPinToInterrupt(PIN_ENC_2), updateEncoder, CHANGE);
  attachInterrupt(digitalPinToInterrupt(PIN_ENC_BUTTON), buttonPush, RISING);
*/

   adxl.powerOn();           
   adxl.setRangeSetting(16);       //Definir el rango, valores 2, 4, 8 o 16

   randomSeed(analogRead(A0));

  // init displays
  for (byte i=0; i<2; i++) {
    lc.shutdown(i,false);
    lc.setIntensity(i,0);     //Controla la intensidad de brillo en las particulas
    
  }
  // Inicializa el temporizador de caída de partículas al inicio
  particleDropTimer.Delay(particleDropDelayMillis); // Usará el valor predeterminado de 1000ms al inicio
  d.Delay(100); // O tu valor original de DELAY_FRAME

  resetTime();
  
}



/**
 * Main loop
 */
void loop() {
  // --- Manejo de la comunicación serial con ESP32 ---
  while (Serial.available()) {
    char inChar = Serial.read();
    if (inChar == '\n') {
      newMessageFlag = true;
      break;
    } else {
      receivedMessage += inChar;
    }
  }

  if (newMessageFlag) {
    Serial.print("Mensaje de ESP32: ");
    Serial.println(receivedMessage);

    if (receivedMessage.startsWith("Tiempo: ")) {
      String timePart = receivedMessage.substring(8);
      int colonIndex = timePart.indexOf(':');
      if (colonIndex != -1) {
        int receivedMin = timePart.substring(0, colonIndex).toInt();
        int receivedSec = timePart.substring(colonIndex + 1).toInt();

        totalDurationMillis = (unsigned long)(receivedMin * 60UL + receivedSec) * 1000UL;
        startTimeMillis = millis();
        countdownActive = true; // Activa la cuenta regresiva de la LCD

        lcd.clear();
        lcd.setCursor(0, 0);
        lcd.print(receivedMessage);

        // --- LÓGICA PARA SINCRONIZAR LA CAÍDA DE PARTÍCULAS ---
        long totalDurationSeconds = receivedMin * 60L + receivedSec;
        
        if (totalDurationSeconds > 0) {
            // Queremos que las 60 partículas caigan en 'totalDurationSeconds' segundos.
            // Entonces, cada partícula debe caer cada (totalDurationSeconds * 1000ms) / 60 "eventos de caída"
            particleDropDelayMillis = max(50UL, (unsigned long)(totalDurationSeconds * 1000UL) / 64UL);
            // El 50UL es un mínimo para que no sea demasiado rápido o 0
        } else {
            // Si el tiempo es 0, usamos el valor predeterminado (1 segundo por partícula)
            particleDropDelayMillis = 1000;
        }
        
        Serial.print("Nuevo particleDropDelayMillis: ");
        Serial.println(particleDropDelayMillis);

        resetTime(); // Reiniciar la animación y el temporizador de caída de partículas
      }
    } else {
      // Si llega cualquier otro mensaje (no "Tiempo: "), desactiva la cuenta
      lcd.clear();
      lcd.setCursor(0, 0);
      lcd.print(receivedMessage);
      if (receivedMessage.length() > 16) {
        lcd.setCursor(0, 1);
        lcd.print(receivedMessage.substring(16));
      }
      countdownActive = false;
      
      // Restaurar la velocidad de caída de partículas a la predeterminada
      particleDropDelayMillis = 1000; // Vuelve a 1 segundo por partícula
      resetTime(); // Reiniciar la animación del reloj de arena a su velocidad normal
    }

    receivedMessage = "";
    newMessageFlag = false;
  }
  // --- Fin del manejo de la comunicación serial ---

  // --- Lógica de la cuenta regresiva en la LCD ---
  if (countdownActive) {
    unsigned long elapsedTime = millis() - startTimeMillis;
    long remainingTimeMillis = totalDurationMillis - elapsedTime;

    if (remainingTimeMillis <= 0) {
      remainingTimeMillis = 0;
      countdownActive = false; // La cuenta regresiva ha terminado

      lcd.clear();
      lcd.setCursor(0, 0);
      if (esperandoTiempoPara) {
        lcd.print("Abierta");
      } else {
        lcd.print("Cerrada");
      }
      
      // Restaurar la velocidad de caída de partículas a la predeterminada cuando la cuenta termina
      particleDropDelayMillis = 1000; // Vuelve a 1 segundo por partícula
      resetTime(); // Reiniciar la animación del reloj de arena a su velocidad normal
    }

    // Actualiza la pantalla solo cada segundo
    if (millis() - lastSecondUpdate >= 1000 || lastSecondUpdate == 0) {
      long remainingSeconds = remainingTimeMillis / 1000UL;
      int displayMinutes = remainingSeconds / 60;
      int displaySeconds = remainingSeconds % 60;

      String displayStr = "Tiempo: ";
      displayStr += String(displayMinutes);
      displayStr += ":";
      if (displaySeconds < 10) displayStr += "0";
      displayStr += String(displaySeconds);

      lcd.clear();
      lcd.setCursor(0, 0);
      lcd.print(displayStr);

      lastSecondUpdate = millis();
    }
  }
  // --- Fin de la lógica de cuenta regresiva ---

  // --- Lógica de la animación de las partículas dentro de las matrices ---
  // Esta parte debe ejecutarse a una velocidad constante (tu DELAY_FRAME original)
  // para que el movimiento interno de la arena sea fluido.
  // Tu objeto 'd' debería controlar esto, asegurándote que se inicialice en setup() con un valor fijo.
  if (d.Timeout()) { // Asumo que 'd' es tu objeto NonBlockDelay para la velocidad interna
      d.Delay(100); // <-- Puedes usar un valor fijo aquí, como 100ms (tu DELAY_FRAME original)
      
      gravity = getGravity();
      lc.setRotation((ROTATION_OFFSET + gravity) % 360);

      // manejar modos especiales (configuración manual de minutos/horas)
      if (mode == MODE_SETMINUTES) {
        renderSetMinutes(); return; 
      } else if (mode == MODE_SETHOURS) {
        renderSetHours(); return;
      }

      // Lógica de movimiento de partículas del reloj de arena
      bool moved = updateMatrix();
      bool dropped = dropParticle(); // <-- Esta función ahora controla su propia temporización

      // Alarma cuando todo está en la parte inferior
      if (!moved && !dropped && !alarmWentOff && (countParticles(getTopMatrix()) == 0)) {
         // alarmWentOff = true;
         // alarm();
         // resetTime();
      }
      // reset alarm flag next time a particle was dropped
      if (dropped) {
        alarmWentOff = false;
      }
  }
  // --- Fin de la lógica de la animación de las partículas ---

  // No necesitamos delay(DELAY_FRAME); aquí, ya que la temporización es no bloqueante
}