#include <Arduino.h>
#include <ESP32Servo.h>
#include <Keypad.h>
#include <WiFi.h>
#include <AsyncTCP.h>
#include <ESPAsyncWebServer.h>
#include <SPIFFS.h>
#include <EEPROM.h>
#include <time.h>
#include "apwifieeprommode_async.h"

// --- Pines UART2 ---
//#define RESET_EEPROM
#define RXD2 16
#define TXD2 17
void moverServos(int angle);
void manejarTeclado();
// --- Servo ---
Servo myservo;
const int pinServo = 18;
int currentAngle = 0;

// --- PIR ---
const int pinPir = 19;
bool sistemaActivo = false;
unsigned long lastMotionTime = 0;
const unsigned long TIEMPO_PIR = 10000;
bool operacionManualActiva = false;
bool bloquearDesactivacion = false;

// --- Botones ---
const int btnOpen = 4;
const int btnClose = 5;
const int btnCode = 34;
const int btnReset = 35;

bool codeMode = false;

unsigned long closeStartTime = 0;
bool closeButtonPressed = false;
bool closeServoMoved = false;

unsigned long openStartTime = 0;
bool openButtonPressed = false;
bool openServoMoved = false;

// --- Tiempo personalizado ---
unsigned long tiempoEsperado = 10000;

// --- Teclado ---
const byte ROWS = 4;
const byte COLS = 4;
char keys[ROWS][COLS] = {
  {'1','2','3','A'},
  {'4','5','6','B'},
  {'7','8','9','C'},
  {'*','0','#','D'}
};
byte rowPins[ROWS] = {13, 12, 14, 27};
byte colPins[COLS] = {26, 25, 33, 32};
Keypad keypad = Keypad(makeKeymap(keys), rowPins, colPins, ROWS, COLS);

String password = "1234";
String input = "";


enum EstadoTiempo { NONE, INGRESAR_MINUTOS, INGRESAR_SEGUNDOS };
EstadoTiempo estadoTiempo = NONE;
int minutos = 0, segundos = 0;
bool esperandoTiempoPara = false;
String entradaTiempo = "";

// --- Web y WiFi ---
AsyncWebServer server(80);
std::vector<String> registros;

void moverServos(int angle) {
  myservo.write(angle);
  currentAngle = angle;
  if (angle == 0) bloquearDesactivacion = false;
  Serial2.println(angle == 0 ? "Cerrada" : "Abierta");
}

void limpiarRegistros() {
  registros.clear();
  File file = SPIFFS.open("/registros.txt", FILE_WRITE);
  file.print("");
  file.close();
}

void resetEEPROM() {
  Serial.println("Borrando EEPROM...");
  EEPROM.begin(512);  // Tamaño típico de EEPROM en ESP32
  for (int i = 0; i < 512; i++) {
    EEPROM.write(i, 0);
  }
  EEPROM.commit();
  Serial.println("EEPROM reseteada.");
}

void agregarRegistro(String mensaje) {
  struct tm timeinfo;
  if (!getLocalTime(&timeinfo)) {
    Serial.println("⚠️ No se pudo obtener la hora. No se registró el evento.");
    return;
  }

  char buffer[30];
  strftime(buffer, sizeof(buffer), "%Y-%m-%d %H:%M:%S", &timeinfo);
  String entry = String(buffer) + ": " + mensaje;
  registros.push_back(entry);

  File file = SPIFFS.open("/registros.txt", FILE_APPEND);
  if (!file) {
    Serial.println("❌ No se pudo abrir registros.txt para escribir");
    return;
  }

  file.println(entry);
  file.close();
  Serial.println("📝 Registro guardado: " + entry);
}


void manejarTeclado();

void setup() {
 Serial.begin(9600);
  delay(1000);  // Espera para que el monitor serial se estabilice

#ifdef RESET_EEPROM
  Serial.println("Borrando EEPROM...");
  resetEEPROM(); // SOLO se ejecuta si RESET_EEPROM está definido
  delay(3000);
  ESP.restart();
#endif
  Serial2.begin(9600, SERIAL_8N1, RXD2, TXD2);

  const int pwmChannel = 0;         // Canal 0
  const int pwmFreq = 50;           // 50 Hz para servo
  const int pwmResolution = 12;     // Resolución de 16 bits

  ledcSetup(pwmChannel, pwmFreq, pwmResolution);
  ledcAttachPin(pinServo, pwmChannel);

  myservo.setPeriodHertz(50);               // Frecuencia típica para servo
  myservo.attach(pinServo, 500, 2400);       // Forzar mapeo de pulsos
  moverServos(0);

  pinMode(btnOpen, INPUT_PULLUP);
  pinMode(btnClose, INPUT_PULLUP);
  pinMode(btnCode, INPUT_PULLUP);
  pinMode(btnReset, INPUT_PULLUP);
  pinMode(pinPir, INPUT);

  Serial2.println("Caja Fuerte");
  Serial.println("Caja Fuerte");

  intentoconexion("ESP32_Config", "12345678");

  configTime(-5 * 3600, 0, "pool.ntp.org");
  SPIFFS.begin(true);
  File file = SPIFFS.open("/registros.txt", FILE_READ);
  while (file.available()) registros.push_back(file.readStringUntil('\n'));
  file.close();

  server.on("/", HTTP_GET, [](AsyncWebServerRequest *request) {
    request->send(SPIFFS, "/index.html", "text/html");
  });

  server.on("/api/open", HTTP_GET, [](AsyncWebServerRequest *request) {
    moverServos(50);
    agregarRegistro("Caja abierta por web");
    request->send(200, "text/plain", "Abierta");
  });

  server.on("/api/close", HTTP_GET, [](AsyncWebServerRequest *request) {
    moverServos(0);
    agregarRegistro("Caja cerrada por web");
    request->send(200, "text/plain", "Cerrada");
  });

  server.on("/api/clear", HTTP_GET, [](AsyncWebServerRequest *request) {
    limpiarRegistros();
    request->send(200, "text/plain", "Registros borrados");
  });

  server.on("/api/logs", HTTP_GET, [](AsyncWebServerRequest *request) {
    String json = "[";
    for (size_t i = 0; i < registros.size(); i++) {
      json += "\"" + registros[i] + "\"";
      if (i < registros.size() - 1) json += ",";
    }
    json += "]";
    request->send(200, "application/json", json);
  });

  server.begin();
}

void loop() {
  bool movimientoDetectado = digitalRead(pinPir) == HIGH;
  if (movimientoDetectado) {
    lastMotionTime = millis();
    if (!sistemaActivo) {
      sistemaActivo = true;
      Serial.println("Movimiento detectado. Sistema ACTIVADO.");
      Serial2.println("Movimiento Detectado");
    }
  }

  if (sistemaActivo && millis() - lastMotionTime > TIEMPO_PIR && !bloquearDesactivacion && currentAngle == 0) {
    sistemaActivo = false;
    Serial.println("No se detectó movimiento. Sistema DESACTIVADO.");
    Serial2.println("Sistema Desactivado");
  }

  if (sistemaActivo) {
    // --- ABRIR ---
    if (digitalRead(btnOpen) == LOW && estadoTiempo == NONE && currentAngle != 50) {
      operacionManualActiva = true;
      esperandoTiempoPara = true;
      estadoTiempo = INGRESAR_MINUTOS;
      entradaTiempo = "";
      bloquearDesactivacion = true; // ← NUEVO
      Serial.println("Ingrese minutos para abrir y presione #: ");
      Serial2.println("Abrir: Minutos");
      delay(300);
    }

    // --- CERRAR ---
    if (digitalRead(btnClose) == LOW && estadoTiempo == NONE && currentAngle != 0) {
      operacionManualActiva = true;
      esperandoTiempoPara = false;
      estadoTiempo = INGRESAR_MINUTOS;
      entradaTiempo = "";
      bloquearDesactivacion = true; // ← NUEVO
      Serial.println("Ingrese minutos para cerrar y presione #: ");
      Serial2.println("Cerrar: Minutos");
      delay(300);
    }

    // --- Código teclado ---
    if (digitalRead(btnCode) == LOW) {
      codeMode = true;
      operacionManualActiva = true;
      bloquearDesactivacion = true; // ← NUEVO
      Serial.println("Ingrese código en el teclado:");
      Serial2.println("Ingrese Codigo");
      delay(300);
    }

    if (digitalRead(btnReset) == LOW) {
      moverServos(0);
      agregarRegistro("Cierre automático realizado.");
      delay(300);
    }

    manejarTeclado();

    // Verifica si debe abrir
    if (openButtonPressed && !openServoMoved && millis() - openStartTime >= tiempoEsperado) {
      moverServos(50);  
      agregarRegistro("Caja abierta por tiempo.");
      openServoMoved = true;
      Serial.println("Caja fuerte abierta.");
      Serial2.println("Abierta");
    }

    // Verifica si debe cerrar
    if (closeButtonPressed && !closeServoMoved && millis() - closeStartTime >= tiempoEsperado) {
      moverServos(0);
      agregarRegistro("Caja cerrada por tiempo");
      closeServoMoved = true;
      Serial.println("Caja fuerte cerrada.");
      Serial2.println("Cerrada");
    }

    // Reset botón abrir
    if (digitalRead(btnOpen) == HIGH && openServoMoved) {
      openButtonPressed = false;
      openServoMoved = false;
    }

    // Reset botón cerrar
    if (digitalRead(btnClose) == HIGH && closeServoMoved) {
      closeButtonPressed = false;
      closeServoMoved = false;
    }

    // Liberar control manual
    if (!openButtonPressed && !closeButtonPressed && !codeMode && estadoTiempo == NONE) {
      operacionManualActiva = false;
    }
  }

  delay(100);
}

void manejarTeclado() {
  char key = keypad.getKey();
  if (!key) return;

  // --- Modo código ---
  if (codeMode) {
    Serial.print("Tecla: ");
    Serial.println(key);

    if (key == '#') {
      if (input == password) {
        Serial.println("Código correcto.");
        Serial2.println("Codigo Correcto");
        moverServos(50);
        agregarRegistro("Caja abierta por código");
      } else {
        Serial.println("Código incorrecto.");
        Serial2.println("Codigo Incorrecto");
        agregarRegistro("Código incorrecto ingresado.");
      }
      input = "";
      codeMode = false;
    } else if (key == '*') {
      input = "";
      Serial.println("Entrada cancelada.");
      Serial2.println("Entrada Cancelada");
      codeMode = false; // Asegúrate de salir del modo código
    } else {

      input += key;
      // Enviar el código digitado a la LCD cada vez que se presiona una tecla
      Serial2.print("Codigo:"); // Prefijo para la LCD
      Serial2.println(input);   // Muestra lo que se ha digitado hasta ahora
    }
    return;
  }

  // --- Modo tiempo personalizado ---
  if (estadoTiempo != NONE) {
    if (key >= '0' && key <= '9') {
      entradaTiempo += key;
      Serial.print(key);
      // Enviar la entrada de tiempo a la LCD
      if (estadoTiempo == INGRESAR_MINUTOS) {
        Serial2.print("Minutos?");
      } else { // INGRESAR_SEGUNDOS
        Serial2.print("Segundos?");
      }
      Serial2.println(entradaTiempo); // Muestra lo que se ha digitado hasta ahora
    } else if (key == '#') {
      int valor = entradaTiempo.toInt();
      entradaTiempo = ""; // Limpiar la entrada de tiempo después de convertir

      if (estadoTiempo == INGRESAR_MINUTOS) {
        minutos = valor;
        estadoTiempo = INGRESAR_SEGUNDOS;
        Serial.println("\nMinutos ingresados.");
        Serial2.print("Minutos: "); // Confirmación y valor
        Serial2.println(minutos);
        // Introducimos un pequeño delay aquí para que el mensaje "Minutos: X" sea visible
        delay(1000); // Espera 1 segundo
        Serial.println("Ingrese segundos y presione #: ");
        Serial2.println("Segundos?"); // Pedir segundos, sin el valor aún
      } else if (estadoTiempo == INGRESAR_SEGUNDOS) {
        segundos = valor;
        estadoTiempo = NONE;
        Serial.println("\nSegundos ingresados.");
        Serial2.print("Segundos: "); // Confirmación y valor
        Serial2.println(segundos);
        // Introducimos un pequeño delay aquí para que el mensaje "Segundos: X" sea visible
        delay(1000); // Espera 1 segundo


        tiempoEsperado = (minutos * 60UL + segundos) * 1000UL;
        Serial.print("Tiempo configurado: ");
        Serial.print(minutos);
        Serial.print(" min ");
        Serial.print(segundos);
        Serial.println(" s");
        
        // Mensaje final del tiempo configurado en formato 1:30
        String tiempoStr = "Tiempo: ";
        tiempoStr += String(minutos);
        tiempoStr += ":";
        if (segundos < 10) tiempoStr += "0"; // Añadir cero si los segundos son < 10
        tiempoStr += String(segundos);
        Serial2.println(tiempoStr); // Este es el mensaje que queremos que se quede

        // Elimina o comenta las siguientes líneas para que no aparezcan "Abriendo en..."/"Cerrando en..." justo después
        // if (esperandoTiempoPara) {
        //   openStartTime = millis();
        //   openButtonPressed = true;
        //   openServoMoved = false;
        //   Serial2.println("Abriendo en...");
        // } else {
        //   closeStartTime = millis();
        //   closeButtonPressed = true;
        //   closeServoMoved = false;
        //   Serial2.println("Cerrando en...");
        // }

        // Mueve la lógica de inicio de la cuenta regresiva fuera del "if (esperandoTiempoPara)"
        // para que solo se inicie la cuenta regresiva sin enviar otro mensaje a la LCD
        if (esperandoTiempoPara) {
            openStartTime = millis();
            openButtonPressed = true;
            openServoMoved = false;
        } else {
            closeStartTime = millis();
            closeButtonPressed = true;
            closeServoMoved = false;
        }


        operacionManualActiva = false;
      }
    } else if (key == '*') {
      entradaTiempo = "";
      Serial.println("\nEntrada cancelada.");
      Serial2.println("Entrada Cancelada");
      estadoTiempo = NONE; // Asegúrate de salir del modo tiempo
    }
  }
} 