#ifndef APWIFIEEPROMMODE_ASYNC_H
#define APWIFIEEPROMMODE_ASYNC_H

#include <WiFi.h>
#include <EEPROM.h>
#include <ESPAsyncWebServer.h>

AsyncWebServer configServer(80);

String leerStringDeEEPROM(int direccion) {
  String cadena = "";
  char caracter = EEPROM.read(direccion);
  int i = 0;
  while (caracter != '\0' && i < 100) {
    cadena += caracter;
    i++;
    caracter = EEPROM.read(direccion + i);
  }
  return cadena;
}

void escribirStringEnEEPROM(int direccion, String cadena) {
  int longitud = cadena.length();
  for (int i = 0; i < longitud; i++) {
    EEPROM.write(direccion + i, cadena[i]);
  }
  EEPROM.write(direccion + longitud, '\0');
  EEPROM.commit();
}

void intentoconexion(const char* ap_ssid, const char* ap_pass) {
  EEPROM.begin(512);
  String ssidEEPROM = leerStringDeEEPROM(0);
  String passEEPROM = leerStringDeEEPROM(100);

  WiFi.begin(ssidEEPROM.c_str(), passEEPROM.c_str());
  Serial.print("Intentando conectar a ");
  Serial.println(ssidEEPROM);

  unsigned long start = millis();
  while (WiFi.status() != WL_CONNECTED && millis() - start < 10000) {
    delay(500);
    Serial.print(".");
  }

  if (WiFi.status() == WL_CONNECTED) {
    Serial.println("\n✅ Conectado a WiFi!");
    Serial.println(WiFi.localIP());
    return;
  }

  Serial.println("\n⚠️ Fallo al conectar. Iniciando modo AP...");
  WiFi.softAP(ap_ssid, ap_pass);
  IPAddress IP = WiFi.softAPIP();
  Serial.print("AP IP: ");
  Serial.println(IP);

  configServer.on("/", HTTP_GET, [](AsyncWebServerRequest *request){
    String html = "<html><body><form method='POST' action='/wifi'>";
    html += "SSID: <input type='text' name='ssid'><br>";
    html += "Password: <input type='password' name='password'><br>";
    html += "<input type='submit' value='Guardar'>";
    html += "</form></body></html>";
    request->send(200, "text/html", html);
  });

  configServer.on("/wifi", HTTP_POST, [](AsyncWebServerRequest *request){
    String ssid, password;
    if (request->hasParam("ssid", true)) {
      ssid = request->getParam("ssid", true)->value();
    }
    if (request->hasParam("password", true)) {
      password = request->getParam("password", true)->value();
    }

    escribirStringEnEEPROM(0, ssid);
    escribirStringEnEEPROM(100, password);

    request->send(200, "text/html", "<html><body><h1>Datos guardados. Reiniciando...</h1></body></html>");
    delay(1000);
    ESP.restart();
  });

  configServer.begin();
}

#endif
